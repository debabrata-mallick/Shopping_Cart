<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class $table =;$table-; extends Model
{
    //
}
