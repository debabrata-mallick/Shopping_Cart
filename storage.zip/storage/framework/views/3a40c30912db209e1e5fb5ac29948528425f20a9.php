<h1>Hello Dear <?php echo e($firstName.' '.$lastName); ?></h1>
Thanks for join our community....
Your email address is: <?php echo e($email); ?>

Your Mobile number: <?php echo e($phoneNo); ?>


Thanks By...
New Shop Team